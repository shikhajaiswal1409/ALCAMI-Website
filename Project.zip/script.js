function toggleSearch() {
    const searchBox = document.getElementById("search-box");
    searchBox.style.display = searchBox.style.display === "block" ? "none" : "block";
}

function toggleMenu() {
    const navLinks = document.querySelector(".nav-links");
    navLinks.classList.toggle("active");
}
document.addEventListener("DOMContentLoaded", () => {
const counters = document.querySelectorAll(".counter");
let started = false;

const observer = new IntersectionObserver(entries => {
entries.forEach(entry => {
    if (entry.isIntersecting && !started) {
        started = true;
        counters.forEach(counter => {
            let target = +counter.getAttribute("data-target");
            let count = 0;
            let increment = Math.ceil(target / 100); // Adjust speed

            let updateCounter = setInterval(() => {
                count += increment;
                if (count >= target) {
                    counter.innerText = target;
                    clearInterval(updateCounter);
                } else {
                    counter.innerText = count;
                }
            }, 30);
        });
    }
});
}, { threshold: 0.5 });

observer.observe(document.querySelector(".stats-section"));
});

let index = 0;
const slides = document.querySelectorAll('.testimonial');
const dots = document.querySelectorAll('.dot');

function updateSlider() {
    const slider = document.querySelector('.slider');
    slider.style.transform = `translateX(-${index * 100}%)`;

    dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
    });
}

function changeSlide(n) {
    index += n;
    if (index < 0) index = slides.length - 1;
    if (index >= slides.length) index = 0;
    updateSlider();
}

function setSlide(n) {
    index = n;
    updateSlider();
}

// // Auto-slide every 5 seconds
// setInterval(() => {
//     changeSlide(1);
// }, 5000);

document.querySelectorAll('.faq-question').forEach(item => {
    item.addEventListener('click', () => {
        const parent = item.parentNode;
        parent.classList.toggle('active');
    });
});
